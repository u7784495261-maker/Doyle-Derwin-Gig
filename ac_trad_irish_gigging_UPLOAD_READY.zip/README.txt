A + C GIGGING CALENDAR — FULL PACKAGE

Files:
- index.html — complete editable calendar
- manifest.webmanifest — installable PWA configuration
- sw.js — offline caching
- icons/ — app icons

GitHub Pages:
Upload ALL files/folders into the root of your existing repository and replace the old index.html.

Features:
- A + C Watch roster
- 28-day repeating cycle
- Friday/Saturday after-18:00 availability highlighting
- Editable leave/unavailable status
- Manual availability override
- Add a trad/Irish gig to any date
- Gig name and notes
- Edits saved locally on each device
- Premium dark Irish trad/session theme
- Installable as a home-screen app
